package br.com.jonataslaet.productscrudapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsCrudApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
