package br.com.jonataslaet.productscrudapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsCrudApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsCrudApiApplication.class, args);
	}

}
